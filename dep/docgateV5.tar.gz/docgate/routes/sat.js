var express = require('express');
var satgw = require('../lib/satgw');
var router = express.Router();
var async = require('async');
var CFeParser = require('../lib/cfeParser');
var timer = require('../lib/timer');
var db = require("../lib/db");
var audit = require('../lib/audit');

var checkPosAuthorized = function (base64value, callback) {
  db.loadDatabase(function (err) {
    db.find({ classType: "device", active: true }, {}, function (err, device) {
      if (err) throw err;
      if (device && device.length > 0) {
        if (base64value.indexOf(" ") > -1)
          base64value = base64value.replace(/ /g, '+');
        var xml = new Buffer(base64value, 'base64').toString('utf8');
        var pattern = /\<(?: +)?numeroCaixa(?: +)?\>([^\<]+)\<\/(?: +)?numeroCaixa(?: +)?\>/gi;
        var match = pattern.exec(xml);
        if (match && match.length > 0) {
          var intPosNumber = parseInt(match[1]);
          var device = device[0];
          var intAuthorizedPos = device.pos.map(function (valueString) {
            try {
              return parseInt(valueString)
            } catch (err) {
              console.log(err);
              console.log("POS with invalid number: " + valueString);
              return -1;
            }
          });
          callback(null, intAuthorizedPos.indexOf(intPosNumber) > -1);
        } else {
          callback({ exception: { message: "XML sem número de caixa", classname: "satapi" } }, false);
        }
      } else {
        callback({ exception: { message: "Nenhum dispositivo cadastrado", classname: "satapi" } }, false);
      }
    });
  });
}

var updateStats = function (emissionTime, base64value, kind, callback) {
  callback = callback || function (err, result) { };
  CFeParser.getBasicInfo(base64value, kind, function (err, basicInfo) {
    if (!err) {
      basicInfo.kind = kind;
      db.find({ classType: "reports" }, function (err, reports) {
        if (reports && reports.length > 0) {
          reports = reports[0];
            
          //Limite de 20 últimos documentos emitidos para exibição no indicador
          if (reports.lastEmittedDocuments.length > 20) {
            reports.lastEmittedDocuments.splice(0, 1);
          }
          reports.lastEmittedDocuments.push(basicInfo);
            
          //Na mudança de um dia para o outro, zere as variáveis de contagem dos indicadores            
          if (reports.lastEmittedDocuments.length > 0 && (parseInt(basicInfo.date) > parseInt(reports.lastEmittedDocuments[0].date))) {
            reports.indexes.emittedDocuments = 0;
            reports.indexes.responseTimeAvg = 0;
          }
            
          //Cria um registro de auditoria
          var auditRow = audit.new(basicInfo.key, kind);
          audit.append("Caixa " + basicInfo.pos + " requisição de " + kind + " respondida com sucesso para chave " + basicInfo.key);
          audit.save();

          reports.indexes.responseTimeAvg = reports.indexes.responseTimeAvg || 0;
          //Média exponencial móvel do tempo de emissão (para não ter que salvar o tempo de emissão de todos os documentos)                        
          reports.indexes.responseTimeAvg = ((((reports.indexes.responseTimeAvg * 1000) * reports.indexes.emittedDocuments) + emissionTime) / (reports.indexes.emittedDocuments + 1)) / 1000;
          reports.indexes.emittedDocuments++;
            

          //Salva as alterações dos indicadores
          db.update({ classType: "reports" }, { $set: { lastEmittedDocuments: reports.lastEmittedDocuments, indexes: reports.indexes } }, function (err, numReplaced) {
            callback(null, true);
          });

        } else {

          callback({ exception: { message: "Nenhum indicador encontrado", classname: "satapi" } }, false);

        }
      });
    }
  });
}

var vendaFn = function (request, callback) {
  checkPosAuthorized(request.content, function (err, posAuthorized) {
    if (err) {
      callback(err)
    } else {
      if (posAuthorized) {
        timer.start("venda");
        db.loadDatabase(function (err) {
          //Procura o equipamento ativo (somente um)
          db.find({ classType: "device", active: true }, {}, function (err, result) {
            if (err) throw err;
            if (result && result.length > 0) {
      
              //Tenta vender usando o SATGateway com modelo selecionado e o conteúdo passado na requisição
              satgw.venda(result[0].model.alias, request.content, request.headers.sessao, function (err, output) {
                if (err) {
                  callback(err);
                } else {
                  callback(output);
                  var emissionTime = timer.end("venda");
      
                  //Só altera indicadores em caso de sucesso na emissão de venda
                  if (output.responseCode && output.responseCode == 6000) {
                    updateStats(emissionTime, output.responseText, "Venda");
                  }

                }
              });
            } else {
              callback({ exception: { message: "Nenhum dispositivo padrão encontrado", classname: "satapi" } })
            }
          });
        });
      } else {
        callback({ exception: { message: "Caixa não autorizado para emissão", classname: "satapi" } })
      }
    }
  });
}

var cancelamentoFn = function (request, callback) {
  checkPosAuthorized(request.content, function (err, posAuthorized) {
    if (err) {
      callback(err)
    } else {
      if (posAuthorized) {
        timer.start("cancelamento");
        db.loadDatabase(function (err) {
          db.find({ classType: "device", active: true }, {}, function (err, result) {
            if (err) throw err;
            if (result && result.length > 0) {
              satgw.cancelamento(result[0].model.alias, request.content, function (err, output) {
                if (err) {
                  callback(err);
                } else {
                  callback(output);
                  var emissionTime = timer.end("cancelamento");
                  
                  //Só altera indicadores em caso de sucesso na emissão de cancelamento
                  if (output.responseCode && output.responseCode == 7000) {
                    updateStats(emissionTime, output.responseText, "Cancelamento");
                  }
                }
              });
            } else {
              callback({ exception: { message: "Nenhum dispositivo padrão encontrado", classname: "satapi" } })
            }
          });
        });
      } else {
        callback({ exception: { message: "Caixa não autorizado para emissão", classname: "satapi" } })
      }
    }
  });
}

var testFn = function (request, callback) {

  db.loadDatabase(function (err) {
    db.find({ classType: "device", active: true }, {}, function (err, result) {
      if (err) callback(err)
      else {
        var device = null;
        if (result && result.length > 0) {
          device = result[0];
        }
        var alias = request.content.alias || device.model.alias;
        var activationCode = request.content.activationCode || device.activationCode;
        satgw.test(alias, activationCode, function (err, output) {
          if (err)
            callback(err);
          else
            callback(output);
        });
      }
    });
  });
}

var extrairlogFn = function (request, callback) {

  db.loadDatabase(function (err) {
    db.find({ classType: "device", active: true }, {}, function (err, result) {
      if (err) callback(err)
      else {
        var device = null;
        if (result && result.length > 0) {
          device = result[0];
        }
        var alias = request.content.alias || device.model.alias;
        satgw.extrairlog(alias, function (err, output) {
          if (err)
            callback(err);
          else
            callback(output);
        });
      }
    });
  });
}

var sessaoFn = function (request, callback) {

  db.loadDatabase(function (err) {
    db.find({ classType: "device", active: true }, {}, function (err, result) {
      if (err) callback(err)
      else {
        var device = null;
        if (result && result.length > 0) {
          device = result[0];
        }
        var alias = request.content.alias || device.model.alias;
        satgw.sessao(alias, JSON.parse(request.content).sessao, function (err, output) {
          if (err)
            callback(err);
          else
            callback(output);
        });
      }
    });
  });
}

var actionFn = function (request, callback) {
  switch (request.action) {
    case "venda":
      vendaFn(request, callback);
      break;
    case "test":
      testFn(request, callback);
      break;
    case "cancelamento":
      cancelamentoFn(request, callback);
      break;
	case "sessao":
      sessaoFn(request, callback);
      break;
	case "extrairlog":
	  extrairlogFn(request, callback);
	  break;
  }
}

var queue = async.queue(actionFn, 1);

router.post('/venda', function (req, res, next) {

  queue.push({
    action: "venda",
    content: req.body.content,
	headers: {sessao: req.headers.sessao}
  }, function (output) {
    res.send(output);
  });

});

router.post('/cancelamento', function (req, res, next) {

  queue.push({
    action: "cancelamento",
    content: req.body.content
  }, function (output) {
    res.send(output);
  });

});

router.post('/test', function (req, res, next) {

  queue.push({
    action: "test",
    content: req.body
  }, function (output) {
    res.send(output);
  });

});

router.post('/sessao', function (req, res, next) {

  queue.push({
    action: "sessao",
    content: req.body.content
  }, function (output) {
    res.send(output);
  });

});

router.post('/extrairlog', function (req, res, next) {

  queue.push({
    action: "extrairlog",
    content: req.body
  }, function (output) {
    res.send(output);
  });

});

module.exports = router;