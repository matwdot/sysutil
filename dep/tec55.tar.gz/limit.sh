#!/bin/bash
nohup cpulimit -P /opt/Gertec55/tec55usbd -l 20